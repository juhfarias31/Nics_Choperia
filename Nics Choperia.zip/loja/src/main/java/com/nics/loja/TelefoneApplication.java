package com.nics.loja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TelefoneApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(TelefoneApplication.class, args);
	}

}